<?php

require_once("../core/Core.php");

$username = $password = $message = "";
$inputError = "";

if (isset($_POST["btnLogin"])) {
    // Validate Inputs
    if ($_POST["username"] == "" || $_POST["password"] == "") {
        $inputError = '<div class="alert alert-danger alert-dismissible" style="margin: 0 -100%;">
	    <a href="#" class="close" style="margin-top: 1%;" data-dismiss="alert" aria-label="close">&times;</a>
	   <center> Username is required! </center>
	  </div>';
    }

    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $authenticate->verifyUser($username, $password);
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TaskMAV</title>
    <link rel="icon" type="image/png" href="/assets/img/taskmav-logo.png" />
    <link rel="stylesheet" type="text/css" href="/assets/css/melham.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- Start of Header Scripts  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@widgetbot/crate@3" async defer>
        new Crate({
            server: '980634785334575174',
            channel: '980634857942163506',
        })
    </script>
</head>

<body>
    <div class="alert">
        <span class="error"> <?= $inputError; ?></span>
    </div>

    <div class="containers" id="container">
        <div class="form-container log-in-container">
            <form method="POST">
                <h2>LOGIN</h2>
                <input name="username" type="text" id="username" class="form__input" autocomplete="off" placeholder="Email" />
                <i class="fa-solid fa-user"></i>
                <input name="password" type="password" id="password" class="form__input" autocomplete="off" placeholder="Password" />
                <i class="fa-solid fa-eye" id="eye" onclick="toggle()" aria-hidden="true"></i>

                <!-- code inserted for the toggle password -->
                <script>
                    var state = false;

                    function toggle() {
                        if (state) {
                            document.getElementById("password").
                            setAttribute("type", "password");
                            state = false;
                        } else {
                            document.getElementById("password").
                            setAttribute("type", "text");
                            state = true;
                        }
                    }
                </script>

                <a href="forgot-pass">Forgot your password?</a>
                <input type="submit" name="btnLogin" value="Login" />
                <p class="register">Don't have account <span><a href="/account/register">Sign up</a></span></p>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <img src="/assets/img/melham-logo.png" alt="Logo">
                    <p>COLLABORATIVE:RESPECT:INTEGRITY:PRIDE</p>
                </div>
            </div>
        </div>

    </div>
</body>

</html>

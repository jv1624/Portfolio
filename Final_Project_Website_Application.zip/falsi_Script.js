function changePage() {
    window.location.href = "rootfinding.html";
  }
function changePage1() {
  window.location.href = "falsi_Code.html";
}
function changePage2() {
  window.location.href = "falsi.html";
}
function changePage3() {
  window.location.href = "Welcome.html";
  }
  function calculateFalsiMethod() {
    var equation = document.getElementById('equation').value;
    var xl = parseFloat(document.getElementById('xl').value);
    var xr = parseFloat(document.getElementById('xr').value);
    var precision = parseFloat(document.getElementById('precision').value);
  
    // Falsi method algorithm
    if (f(xl) * f(xr) >= 0) {
      document.getElementById('result').innerHTML = "The equation may not have a root in the given interval.";
      return;
    }
  
    var iterations = 1;
    var result = "";
    result += "Falsi Method<br>";
    result += "<table><tr><th>i</th><th>Xl</th><th>Xm</th><th>Xr</th><th>fxl</th><th>fxm</th><th>fxr</th></tr>";
  
    var condition = true;
    while (condition) {
      var fxl = f(xl);
      var fxr = f(xr);
      var xm = xl + (xr - xl) * (fxl / (fxl - fxr));
      var fxm = f(xm);
      result += "<tr><td>" + iterations + "</td><td>" + xl.toFixed(4) + "</td><td>" + xm.toFixed(4) + "</td><td>" + xr.toFixed(4) + "</td><td>" + fxl.toFixed(4) + "</td><td>" + fxm.toFixed(4) + "</td><td>" + fxr.toFixed(4) + "</td></tr>";
      if (fxm == 0) {
        break;
      } else if (fxm * fxl < 0) {
        xr = xm;
      } else {
        xl = xm;
      }
      condition = Math.abs(f(xm)) > precision;
      iterations++;
    }
  
    result += "</table>";
    result += "Validity of assumptions: There is at least one root in the given interval.<br>";
    result += "Complete iterations: " + (iterations-1) + "<br>";
    result += "Root value: " + fxm.toFixed(4);
    document.getElementById('result').innerHTML = result;
  }
  
  function f(x) {
    var equation = document.getElementById('equation').value;
    return eval(equation);
  }
const input1 = document.getElementById("input")

function convertToBinary(decimal, isWhole = false) {
    let whole = Math.floor(Math.abs(decimal));
    const binaryWhole = [];
    const binaryFraction = [];
  
    let binary = '';
  
    while (whole > 0) {
      binaryWhole.unshift((whole % 2).toString());
      whole = Math.floor(whole / 2);
    }
  
    let fraction = Math.abs(decimal - Math.floor(decimal));
    while (fraction > 0) {
      if (binaryFraction.length >= 52) {
        break; // Limit the number of decimal places
      }
      fraction *= 2;
      if (fraction >= 1) {
        binaryFraction.push('1');
        fraction -= 1;
      } else {
        binaryFraction.push('0');
      }
    }
  
    binary = `${binaryWhole.join('')}.${binaryFraction.join('')}`;
  
    if (isWhole) {
      return binaryWhole.join('');
    }
  
    return binary;
  }
  
  function normalizedExponent(decimal, binary) {
    return decimal >= 1 ? binary.indexOf('.') - 1 : binary.indexOf('1') * -1;
  }
  
  function fillMantissa(string, bits) {
    return string.padEnd(bits - 1, '0').substring(0, bits - 1);
  }
  
  function fillExponentDigits(string, bits) {
    return string.padStart(bits, '0').substring(string.length - bits);
  }
  
  function insertAtIndex(string, substring, index) {
    return string.slice(0, index) + substring + string.slice(index);
  }
  
  function normalizeBinary(decimal, binary) {
    if (decimal < 1) {
      return insertAtIndex(binary.slice(binary.indexOf('1')), '.', 1);
    } else {
      return insertAtIndex(binary.replace('.', ''), '.', 1);
    }
  }
  
  function solve32(decimal) {
    const is32bit = true;
    const binary = convertToBinary(decimal);
    const normalizedBinary = normalizeBinary(decimal, binary);
    const bias = normalizedExponent(decimal, binary) + 127;
    const exponent = fillExponentDigits(convertToBinary(bias, true), is32bit ? 8 : 11);
    const mantissa = fillMantissa(normalizedBinary.split('.')[1], 23);
    const sign = decimal < 0 ? '1' : '0';
    return `${sign} ${exponent} ${mantissa}`;
  }
  
  function solve64(decimal) {
    const is32bit = false;
    const binary = convertToBinary(decimal);
    const normalizedBinary = normalizeBinary(decimal, binary);
    const bias = normalizedExponent(decimal, binary) + 1023;
    const exponent = fillExponentDigits(convertToBinary(bias, true), is32bit ? 8 : 11);
    const mantissa = fillMantissa(normalizedBinary.split('.')[1], 52);
    const sign = decimal < 0 ? '1' : '0';
    return `${sign} ${exponent} ${mantissa}`;
  }
  function convertAndPrint() {
    const decimal = parseFloat(document.getElementById("input").value);
    document.getElementById("result32").textContent = `32-bit: ${solve32(decimal)}`;
    document.getElementById("result64").textContent = `64-bit: ${solve64(decimal)}`;
  }
  function changePage() {
    window.location.href = "home.html";
  }
  function changePage1() {
    window.location.href = "IEEE_Code.html";
  }
  function changePage2() {
    window.location.href = "IEEE.html";
  }
  function changePage3() {
    window.location.href = "Welcome.html";
    }
    
  

function changePage() {
    window.location.href = "home.html";
  }
function changePage1() {
    window.location.href = "IEEE.html";
  }
function changePage2() {
    window.location.href = "rootfinding.html";
  }
  function changePage3() {
    window.location.href = "jacobi.html";
  }
  function bisection() {
    window.location.href = "bisection.html";
  }
  function falsi() {
    window.location.href = "falsi.html";
  }
  function newton() {
    window.location.href = "newton.html";
  }
  function secant() {
    window.location.href = "secant.html";
  }
function changePage3() {
    window.location.href = "jacobi.html";
  }
function changePage4() {
  window.location.href = "Welcome.html";
  }
  

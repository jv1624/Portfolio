function changePage() {
    window.location.href = "rootfinding.html";
  }
  function changePage1() {
    window.location.href = "secant_Code.html";
  }
  function changePage2() {
    window.location.href = "secant.html";
  }
  function changePage3() {
    window.location.href = "Welcome.html";
    }
    function f(x, equation) {
        return eval(equation);
      }
      
      function secantM(x0, x1, e, equation) {
        let step = 1;
        let table = [];
        table.push(['i', 'Xl', 'Xr', 'Xn', 'Yl', 'Yr', 'Yn']);
      
        let condition = true;
      
        let x2 = x0; // Initialize x2
      
        while (condition) {
          x2 = x0 - ((f(x0, equation) * (x0 - x1)) / (f(x0, equation) - f(x1, equation)));
          const row = [
            step,
            x0.toFixed(4),
            x1.toFixed(4),
            x2.toFixed(4),
            f(x0, equation).toFixed(4),
            f(x1, equation).toFixed(4),
            f(x2, equation).toFixed(4)
          ];
          table.push(row);
      
          x0 = x1;
          x1 = x2;
      
          step++;
          condition = Math.abs(f(x2, equation)) > e;
        }
      
        // Display the table
        const tableContainer = document.getElementById('table-container');
        tableContainer.innerHTML = '';
      
        const tableElem = document.createElement('table');
      
        for (const row of table) {
          const tr = document.createElement('tr');
          for (const cell of row) {
            const td = document.createElement('td');
            td.textContent = cell;
            tr.appendChild(td);
          }
          tableElem.appendChild(tr);
        }
      
        tableContainer.appendChild(tableElem);
      
        const rootValue = document.createElement('p');
        rootValue.textContent = 'Root Value is: ' + x2.toFixed(4);
        tableContainer.appendChild(rootValue);
      }
      
      document.getElementById('calculate-button').addEventListener('click', function() {
        const equation = document.getElementById('equation-input').value;
        const xl = parseFloat(document.getElementById('xl-input').value);
        const xr = parseFloat(document.getElementById('xr-input').value);
        const precision = parseFloat(document.getElementById('precision-input').value);
      
        secantM(xl, xr, precision, equation);
      });
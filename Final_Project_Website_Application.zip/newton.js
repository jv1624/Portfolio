function changePage() {
    window.location.href = "rootfinding.html";
  }
  function changePage1() {
    window.location.href = "newton_code.html";
  }
  function changePage2() {
    window.location.href = "newton.html";
  }
  function changePage3() {
    window.location.href = "Welcome.html";
    }
    function performNewtonRhapson() {
        const functionInput = document.getElementById('functionInput').value;
        const xoInput = parseFloat(document.getElementById('xoInput').value);
        const yoInput = parseFloat(document.getElementById('yoInput').value);
        const precisionInput = parseFloat(document.getElementById('precisionInput').value);

        const table = document.getElementById('outputTable');
        table.innerHTML = '<tr><th>i</th><th>Xn</th><th>Xo</th><th>Yn</th><th>Yo</th></tr>';

        let i = 1;
        let xo = xoInput;
        let yo = yoInput;

        function evaluateFunction(x) {
            // Evaluate the given function here
            return eval(functionInput);
        }

        function evaluateDerivative(x) {
            // Evaluate the derivative of the given function here
            // You can use numerical approximation methods like the central difference method
            const h = 0.0001;
            const f1 = evaluateFunction(x + h);
            const f2 = evaluateFunction(x - h);
            return (f1 - f2) / (2 * h);
        }

        while (Math.abs(yo) > precisionInput) {
            const f = evaluateFunction(xo);
            const df = evaluateDerivative(xo);
            const xn = xo - (f / df);
            const yn = evaluateFunction(xn);

            const row = table.insertRow();
            row.innerHTML = `<td>${i}</td><td>${xn.toFixed(4)}</td><td>${xo.toFixed(4)}</td><td>${yn.toFixed(4)}</td><td>${yo.toFixed(4)}</td>`;

            i++;
            xo = xn;
            yo = yn;
        }
    }